# PyCrack
Code to compute PMKs, PTKs, and MICs given data from a 4-way handshake. Code to perform an offline dictionary attack is also provided. See [the related blog post](https://nicholastsmith.wordpress.com/2016/11/15/wpa2-key-derivation-with-anaconda-python/#more-1403) for more details.
